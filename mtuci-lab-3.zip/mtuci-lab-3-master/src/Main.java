
public class Main {
    public static void main(String[] args) {

        String s1 = "12";
        String s2 = "21";

        System.out.println(s1 = s2);
    }
}